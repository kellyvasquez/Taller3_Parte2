from django.apps import AppConfig


class NoticiasConfig(AppConfig):
    name = 'noticias'
    verbose_name = 'Noticias'
